-- AlterTable
ALTER TABLE `Schedule` MODIFY `end` DATETIME(3) NULL;
