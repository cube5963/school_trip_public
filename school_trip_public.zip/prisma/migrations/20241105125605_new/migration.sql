-- AlterTable
ALTER TABLE `Schedule` ADD COLUMN `destinations` VARCHAR(191) NULL;
