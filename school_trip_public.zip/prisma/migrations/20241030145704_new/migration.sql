-- AlterTable
ALTER TABLE `User` MODIFY `username` VARCHAR(191) NULL,
    MODIFY `password` VARCHAR(191) NULL,
    MODIFY `group` INTEGER NULL;
